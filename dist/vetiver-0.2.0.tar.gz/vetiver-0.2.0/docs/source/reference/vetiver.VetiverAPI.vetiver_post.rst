﻿vetiver.VetiverAPI.vetiver\_post
================================

.. currentmodule:: vetiver

.. automethod:: VetiverAPI.vetiver_post
