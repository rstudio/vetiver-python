﻿vetiver.vetiver\_write\_app
===========================

.. currentmodule:: vetiver

.. autofunction:: vetiver_write_app
