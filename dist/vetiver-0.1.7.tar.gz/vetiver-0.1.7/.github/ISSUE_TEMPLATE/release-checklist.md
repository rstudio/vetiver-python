---
name: Release checklist
about: prepare for relase
title: Release vetiver X.X.X
labels: release
assignees: ''

---

Prepare for release:

- [ ] `pre-commit run`
- [ ] `pytest vetiver/tests/`
- [ ] bump release number

Submit to PyPI:
- [ ] submit 🎉
