﻿vetiver.load\_pkgs
==================

.. currentmodule:: vetiver

.. autofunction:: load_pkgs
