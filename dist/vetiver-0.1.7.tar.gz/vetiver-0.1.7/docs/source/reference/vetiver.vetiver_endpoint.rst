﻿vetiver.vetiver\_endpoint
=========================

.. currentmodule:: vetiver

.. autofunction:: vetiver_endpoint
