﻿vetiver.VetiverAPI
==================

.. currentmodule:: vetiver

.. autoclass:: VetiverAPI


   .. automethod:: __init__


   .. rubric:: Methods

   .. autosummary::

      ~VetiverAPI.__init__
      ~VetiverAPI.run
      ~VetiverAPI.vetiver_post





   .. rubric:: Attributes

   .. autosummary::

      ~VetiverAPI.app
