﻿vetiver.VetiverAPI.run
======================

.. currentmodule:: vetiver

.. automethod:: VetiverAPI.run
