﻿vetiver.vetiver\_write\_docker
==============================

.. currentmodule:: vetiver

.. autofunction:: vetiver_write_docker
