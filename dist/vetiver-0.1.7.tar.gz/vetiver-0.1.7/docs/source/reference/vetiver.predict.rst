﻿vetiver.predict
===============

.. currentmodule:: vetiver

.. autofunction:: predict
