﻿vetiver.VetiverModel
====================

.. currentmodule:: vetiver

.. autoclass:: VetiverModel


   .. automethod:: __init__


   .. rubric:: Methods

   .. autosummary::

      ~VetiverModel.__init__
